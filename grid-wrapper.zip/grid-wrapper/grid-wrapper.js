(function($) {
	
	'use strict';
	
	var LOCKED_ICON_CLASS = 'column-locked-icon';
	var UNLOCK_ICON_CLASS = 'column-unlock-icon';
	var UNLOCK_ICON = '<img src="img/grid/unlock.png">';
	var LOCKED_ICON = '<img src="img/grid/lock.png">';
    
	/**
	 * コントローラ
	 *
	 * @class nssol.nsc.GridWrapperController
	 *
	 */
	var gridWrapperController =  {
		
		/**
		 * コントローラ名
		 *
		 * @memberOf nssol.nsc.GridWrapperController
		 * @type string
		 */
		__name: 'nssol.nsc.GridWrapperController',
	
		/**
		 * PagingGridControllerライブラリ
		 *
		 * @memberOf nssol.nsc.GridWrapperController
		 * @type Controller
		 */
		h5GridController: h5.ui.components.datagrid.PagingGridController,
		
		/**
		 * 移動元カラムID
		 *
		 * @memberOf nssol.nsc.GridWrapperController
		 * 
		 */
		_selectedColumnId: null,
		
		/**
		 * 移動先カラムID
		 *
		 * @memberOf nssol.nsc.GridWrapperController
		 * 
		 */
		_targetColumnId: null,
		
		/**
		 * デフォルトfixedカラム数
		 *
		 * @memberOf nssol.nsc.GridWrapperController
		 * 
		 */
		_oldHeaderColumns: null,
		
		/**
		 * カラム移動フラッグ
		 * 未移動：false, 移動後：true
		 *
		 * @memberOf nssol.nsc.GridWrapperController
		 * 
		 */
		_moveFlag: false,


		// --- Life Cycle Method --- //

        // --- Event Handler --- //

        '{rootElement} renderGrid': function() {
			if (!this._moveFlag){
				this._oldHeaderColumns = this.$find('.grid-header-top-left-cells tr td').length;
			}
            this._appendLockIcons();
        },

		/**
		 * unlockアイコンをクリック時に起こるイベントハンドラ
		 *
		 * @memberOf nssol.nsc.GridWrapperController
		 * @param {Object}
		 *            context コンテキスト
		 * @param {jQuery}
		 *            $el イベントの起きた要素
		 */
		'.column-unlock-icon click': function(context, $el) {
			this._moveFlag = true; 

        	this._selectedColumnId = $el.closest('.grid-header').data('h5DynGridColumnId');
        	this._targetColumnId = this.$find('.grid-header-top-left-cells tr td').length;
        	this.h5GridController._gridLayoutController._headerColumns = this._targetColumnId + 1;
			this._moveColumn();
		},
		
		/**
		 * lockedアイコンをクリック時に起こるイベントハンドラ
		 *
		 * @memberOf nssol.nsc.GridWrapperController
		 * @param {Object}
		 *            context コンテキスト
		 * @param {jQuery}
		 *            $el イベントの起きた要素
		 */
		'.column-locked-icon click': function(context, $el) {
			this._moveFlag = true; 

        	this._selectedColumnId = $el.closest('.grid-header').data('h5DynGridColumnId');
        	this._targetColumnId = this.$find('.grid-header-top-left-cells tr td').length - 1;
        	this.h5GridController._gridLayoutController._headerColumns = this._targetColumnId;
        	this._moveColumn();
			
		},
		
		/**
		 * Gridテキストボックスの値変更するイベントをあげる
		 *
		 * @memberOf nssol.nsc.GridWrapperController
		 *
		 */
		'input[type="text"] blur': function(context, $el) {
			
			var dataId = $el.data('bertDataId');
			var propName = $el.context.name;
			var newValue = $el.context.value;
					
			this.trigger('valueChanged', {
	    		id: dataId,
	    		name: propName,
	    		value: newValue
	    	});
        },
        
        /**
		 * Gridコラムにアイコンを追加
		 *
		 * @memberOf nssol.nsc.GridWrapperController
		 *
		 */
		_appendLockIcons: function() {
			var that = this;
			
			if (this._moveFlag){
				 var $headerLeftCells = this.$find('.grid-header-top-left-cells');
				 $headerLeftCells.find('td, th').each(function(index) {
					if (index >= that._oldHeaderColumns ) {
						var $target = $(this).find('div.grid-cell');
				        that._appendIcon($target, LOCKED_ICON_CLASS, LOCKED_ICON);
					}	
			    });
			 }
			
		    var $headerRows = this.$find('.grid-header-rows');
		    $headerRows.find('td, th').each(function() {
		        var $target = $(this).find('div.grid-cell');
		        that._appendIcon($target, UNLOCK_ICON_CLASS, UNLOCK_ICON);
		    });
		},
		
		/**
		 * アイコンを追加する。
		 *
		 * @memberOf nssol.nsc.GridWrapperController
		 * @param $target 追加する対象の親クラス
		 * @param iconClass 追加するクラス       
		 * @param iconImg 追加するアイコン
		 *            
		 */
		_appendIcon : function($target, iconClass, iconImg) {
			
			var $icon = $('<div>' + iconImg + '</div>');
			$icon.addClass(iconClass).css({
	        	display: 'inline-block',
                float: 'right'
	        });
	
	        $target.append($icon);
						
		},
		
		/**
		 * カラムを移動する
		 *
		 * @memberOf nssol.nsc.GridWrapperController
		 * 
		 */
         _moveColumn: function() {

			var from = this._selectedColumnId;
			var to = this._targetColumnId;
			
			var columns = this.h5GridController._converter.getColumns();
			var fromColumn = columns.splice(from, 1)[0];
			
			columns.splice(to, 0, fromColumn);
			
			this.h5GridController._converter.setColumns(columns);
           
        },

	};
	
	h5.core.expose(gridWrapperController);

})(jQuery);
