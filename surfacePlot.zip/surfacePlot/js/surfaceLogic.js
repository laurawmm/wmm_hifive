(function() {
	// =========================================================================
	// Constants
	// =========================================================================

	var SAMPLE_DATA_FILEPATH = 'json/sampleData.json';

	// =========================================================================
	// Cache
	// =========================================================================

	// =========================================================================
	// Functions
	// =========================================================================

	// =========================================================================
	// Body
	// =========================================================================

	var surfaceLogic = {
		/**
		 * @memberOf sample.chart.logic.SurfaceLogic
		 */
		__name: 'sample.chart.logic.SurfaceLogic',
		/**
		 * モデル
		 */
		model: sample.chart.model.SurfaceModel,

		/**
		 * サーバからデータを取得します。
		 * <p>
		 * ※今回はjsonファイルのサンプルデータを読み込んでいます。
		 * @memberOf sample.chart.logic.SurfaceLogic
		 * @returns {Promise} Promiseオブジェクト
		 */
		init: function() {
			var df = this.deferred();
			var that = this;
            var values = [];
            var tooltipStrings = [];
            var surfaceData = [];

			$.ajax({
				url: SAMPLE_DATA_FILEPATH,
				dataType: 'json',
				cache: false,
				success: function(data) {
					var dataItems = that.model.create(data);
                    $.each(dataItems, function(i, obj) {
                        var delayTime = obj.get('delayTime');
                        values.push(delayTime);
                        tooltipStrings.push( obj.get('city') + "Longitude:" + obj.get('Longitude') + ", Latitudes:" + obj.get('Latitudes') + ", delayTime:" + delayTime);
                    });
                    var surfaceData = {nRows: 5, nCols: 5, formattedValues: values};
                    var data = {surfaceData: surfaceData, tooltipStrings: tooltipStrings};

					df.resolve(data);
				},
				error: function() {
					alert('サンプルデータの読み込みに失敗しました。');
				}
			});

			return df.promise();
		}
	};

	// sample.chart.logic.SurfaceDoLogicでグローバルに公開する
	h5.core.expose(surfaceLogic);
})();
