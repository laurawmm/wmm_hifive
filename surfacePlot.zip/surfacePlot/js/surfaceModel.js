(function() {
	// =========================================================================
	// Constants
	// =========================================================================

	// =========================================================================
	// Cache
	// =========================================================================

	// =========================================================================
	// Body
	// =========================================================================

	// データモデルマネージャを作成する
	var surfaceManager = h5.core.data.createManager('SurfaceManager');

	// データモデルを生成
	var surfaceModel = surfaceManager.createModel({
		name: 'SurfaceModel',
		schema: {
			// ID
			id: {
				id: true,
				type: 'integer'
			},
			// city
            city: {
				type: 'string'
			},
			// ステータス
            Longitude: {
				type: 'string'
			},
            Latitudes: {
				type: 'string'
			},
			// 内容
            distance: {
                type: 'integer'
            },
            // 内容
            peak: {
                type: 'integer'
            },
			// 内容 - スタイル
            delayTime: {
				type: 'integer',
				depend: {
					on: ['distance','peak'],
                    calc: function() {
                        return Math.pow(this.get('distance'),2) * (Math.random() + 0.5) * this.get('peak')/100000;
                    }
				}
			}
		}
	});

	// sample.chart.model.SurfaceModelでグローバルに公開する
	h5.u.obj.expose('sample.chart.model', {
		SurfaceModel: surfaceModel
	});
})();
