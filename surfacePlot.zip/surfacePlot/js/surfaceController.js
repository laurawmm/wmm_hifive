﻿(function() {
	// =========================================================================
	// Constants
	// =========================================================================

	// =========================================================================
	// Cache
	// =========================================================================

	// =========================================================================
	// Functions
	// =========================================================================

	// =========================================================================
	// Body
	// =========================================================================
    var surfaceController = {
        /**
         * @memberOf sample.chart.controller.SurfaceController
         */
        __name: 'sample.chart.controller.SurfaceController',
        surfaceLogic: sample.chart.logic.SurfaceLogic,
        /**
         * SurfacePlotのデータをサーバから取得し画面に表示します。
         * <p>
         * @memberOf sample.chart.controller.SurfaceController
         * @param context
         */
        __ready: function() {
            var that = this;
            this._drawChart();
            //setInterval(function(){that._drawChart();},5000);
        },
        /**
         * バブルチャートを描画する。
         * @memberOf sample.chart.controller.SurfaceController
         */
        _drawChart: function() {

            var that = this;
            this.surfaceLogic.init()
                .done(function(data){

                    var surfacePlot = new SurfacePlot('#surfacePlot');
                    var fillPly = true;

                    // Define a colour gradient.
                    var colour1 = {red:0, green:0, blue:255};
                    var colour2 = {red:0, green:255, blue:255};
                    var colour3 = {red:0, green:255, blue:0};
                    var colour4 = {red:255, green:255, blue:0};
                    var colour5 = {red:255, green:0, blue:0};
                    var colours = [colour1, colour2, colour3, colour4, colour5];

                    // Axis labels.
                    var xAxisHeader	= "X-axis";
                    var yAxisHeader	= "Y-axis";
                    var zAxisHeader	= "Z-axis";

                    var renderDataPoints = false;
                    var background = '#ffffff';
                    var axisForeColour = '#000000';
                    var hideFloorPolygons = true;
                    var chartOrigin = {x: 150, y:150};

                    var basicPlotOptions = {fillPolygons: fillPly, tooltips: data.tooltipStrings, renderPoints: renderDataPoints };

                    options = {xPos: 0, yPos: 0, width: 400, height: 400, colourGradient: colours,
                        xTitle: xAxisHeader, yTitle: yAxisHeader, zTitle: zAxisHeader,
                        backColour: background, axisTextColour: axisForeColour, hideFlatMinPolygons: hideFloorPolygons, origin: chartOrigin};

                    // Options for the webGL plot.
                    var xLabels = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
                    var yLabels = [0, 1, 2, 3, 4, 5];
                    var zLabels = [0, 1, 2, 3, 4, 5, 6]; // These labels ar eused when autoCalcZScale is false;
                    glOptions = {xLabels: xLabels, yLabels: yLabels, zLabels: zLabels, chkControlId: "allowWebGL", autoCalcZScale: false, animate: true};

                    surfacePlot.draw(data.surfacedata, options, basicPlotOptions, glOptions);
                }
            );
        },

        '#btnUpdate click': function() {
            this. _drawChart();
        }
    };

    // sample.chart.controller.SurfaceControllerでグローバルに公開する
    h5.core.expose(surfaceController);
})(jQuery);
