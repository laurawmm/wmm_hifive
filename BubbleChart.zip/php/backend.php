<?php
// データベースへ接続
$con = mysql_connect("localhost","root","hifivepwd");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }
mysql_query("SET NAMES utf8");
mysql_query("SET COLLATION_CONNECTION='utf8_general_ci'");

// リソースの単価と数を取得
$sql_resource = "select * from hifivedb.resource";
$result_resource = mysql_query($sql_resource);
// 総金額
$totalValue = 0;
while ($row_resource = mysql_fetch_array($result_resource, MYSQL_ASSOC))
{
    switch ($row_resource["ITEM"]) {
        case '1vCPU':
            $price_cpu = $row_resource["PRICE"];
            $totalValue += $price_cpu*$row_resource["COUNT"];
            break;
        case '1GMem':
            $price_mem = $row_resource["PRICE"];
            $totalValue += $price_mem*$row_resource["COUNT"];
            break;
        case '1VM(50G)':
            $price_vm = $row_resource["PRICE"];
            $totalValue += $price_vm*$row_resource["COUNT"];
            break;
        case '10GOnline':
            $price_dOnline = $row_resource["PRICE"];
            $totalValue += $price_dOnline*($row_resource["COUNT"]/10);
            break;
        default:
            break;
    }
}

// vmの詳細情報を取得して、画面表示用のレコードを作成
$sql_vm ="select CUSTOMER_NAME, APP_NAME, SUM(CPU)+SUM(MEM)+SUM(DISk) as TOTAl, $totalValue AS TOTAL_VALUE, (SUM(CPU)+SUM(MEM)+SUM(DISk))/$totalValue as PERCENT, EV, X, Y, GROUP_CONCAT(DETAIL order by START_DATE separator '\n') as DETAIL from
       (select vm.CUSTOMER_ID as CUSTOMER_ID, customer.CUSTOMER_NAME as CUSTOMER_NAME, vm.APP_NAME as APP_NAME,
       vm.CPU*$price_cpu as CPU, vm.MEM*$price_mem as MEM,
       cast($price_vm+(vm.DISK-50)*0.1*$price_dOnline as decimal(10,2)) as DISK,
       vm.EV as EV, vm.X as X, vm.Y as Y,
       concat('APP: ', vm.APP_NAME, '\nCPU: ', vm.CPU, ' MEM:', vm.MEM, ' DISK: ', vm.DISK,
       '\n開始日: ', vm.START_DATE, ' 管理者: ', vm.ADMIN) as DETAIL, vm.START_DATE as START_DATE
        from hifivedb.vm as vm, hifivedb.customer as customer
       where hifivedb.vm.CUSTOMER_ID = hifivedb.customer.CUSTOMER_ID) as TEMP
       group by CUSTOMER_ID, EV, x, y";

$result_vm =mysql_query($sql_vm);


// 詳細情報格納用クラス
class Info
{
public $id;
public $customer_name;
public $app_name;
public $total;
public $total_value;
public $percent;
public $ev;
public $x;
public $y;
public $detail;
}

// DBから抽出したデータをアレイに保存する
$tmpCount = 1;
$data =array();
$json ="";
while ($row_ev= mysql_fetch_array($result_vm, MYSQL_ASSOC))
{
    $evInfo=new Info();
    $evInfo->id = $tmpCount;
    $evInfo->customer_name = $row_ev["CUSTOMER_NAME"];
    $evInfo->app_name = $row_ev["APP_NAME"];
    $evInfo->total = $row_ev["TOTAl"];
    $evInfo->total_value = $row_ev["TOTAl_VALUE"];
    $evInfo->percent = $row_ev["PERCENT"];
    $evInfo->ev = $row_ev["EV"];
    $evInfo->x = $row_ev["X"];
    $evInfo->y = $row_ev["Y"];
    $evInfo->detail = $row_ev["DETAIL"];
    $data[]=$evInfo;
    $tmpCount ++;
}
// json型に変化する
$json = json_encode($data);
echo $json;
mysql_close($con);

?>