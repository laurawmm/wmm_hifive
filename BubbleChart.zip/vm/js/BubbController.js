(function() {
	// =========================================================================
	// Constants
	// =========================================================================

	// =========================================================================
	// Cache
	// =========================================================================

	// =========================================================================
	// Functions
	// =========================================================================

	// =========================================================================
	// Body
	// =========================================================================

	var bubbController = {
		/**
		 * @memberOf sample.chart.controller.BubbController
		 */
		__name: 'sample.chart.controller.BubbController',
		bubbLogic: sample.todo.logic.BubbLogic,
		/**
		 * Bubbleのデータをサーバから取得し画面に表示します。
		 * <p>
		 * @memberOf sample.chart.controller.BubbController
		 * @param context
		 */
		__ready: function() {
            var that = this;
            this._drawChart();
            //setInterval(function(){that._drawChart();},5000);
		},
        /**
         * バブルチャートを描画する。
         * @memberOf sample.chart.controller.BubbController
         */
        _drawChart: function() {

            var seriesList = [];
	        var that = this;
            this.bubbLogic.init()
                .done(function(data){
                    $('#wijbubblechart').css("height",$(document).height()*0.8);
                    $("#wijbubblechart").wijbubblechart({
                        horizontal: false,
                    	maximumSize: data.totalvale,
                        legend: {style: {fill: "gainsboro", stroke: "grey"},
                            text: "EV" + '(' + "残りリソース：" + data.left + ')',
                            textMargin: {left: 10, top: 5, right: 10, bottom: 10 },
                            textStyle: {fill: "black", "font-size": 12},
                            titleStyle: {"font-size": 12},
                            visible: true,
                            orientation: "horizontal",
                            compass: "south"
                        },
                        axis: {
                            y: {
                                text: "XXXXXX",
                                textVisible: false
                            },
                            x: {
                                text: "",
                                textVisible: false,
                                gridMajor: {visible: true, style: {"stroke-dasharray": ""}},
                                gridMinor: {visible: true},
                                tickMajor: {position: "cross", style: {stroke: "limegreen"}}
                            }
                        },
                       hint: {
                            content: function () {
                                return this.data.detail;
                            }
                        },
                        header: {
                            text: "VMware Distribution"
                        },

                        seriesList: data.datalist,
                        chartLabel: {
                            position: "inside",
                            style: {fill: "white", "font-size": 10}
                        },
                        shadow:false,
                        seriesStyles: [{},
                            {fill: "90-#FF6600-#FF6600", stroke: "#FF6600"},
                            {fill: "90-#9900CC-#9900CC", stroke: "#9900CC"},
                            {}
                        ]
                    });}
            );
        },

        '#btnUpdate click': function() {
            this. _drawChart();
        }
	};

	// sample.chart.controller.BubbControllerでグローバルに公開する
	h5.core.expose(bubbController);

})(jQuery);
