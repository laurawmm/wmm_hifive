$(function() {
	h5.core.controller('#content', sample.chart.controller.BubbController);
});