(function() {
	// =========================================================================
	// Constants
	// =========================================================================

	var SAMPLE_DATA_FILEPATH = 'http://172.30.79.147:80/php/backend.php';
	// =========================================================================
	// Cache
	// =========================================================================

	// =========================================================================
	// Functions
	// =========================================================================

	// =========================================================================
	// Body
	// =========================================================================

	var bubbLogic = {
		/**
		 * @memberOf sample.chart.logic.BubbLogic
		 */
		__name: 'sample.todo.logic.BubbLogic',

		/**
		 * Bubbleモデル
		 */
		model: sample.chart.model.BubbModel,

		/**
		 * サーバからBubbleデータを取得します。
		 * <p>
		 * ※今回はjsonデータを読み込んでいます。
		 * @memberOf sample.chart.logic.BubbLogic
		 * @returns {Promise} Promiseオブジェクト
		 */
		init: function() {

            var vm_demo = new this._vmClass();
            var vm_poc = new this._vmClass();
            var vm_live = new this._vmClass();
            var vm_ns = new this._vmClass();

            var df = h5.async.deferred();
            var that = this;
            var usedPrice = 0;
            var totalValue = 0;
            var flg = 0;

			h5.ajax({
                url: SAMPLE_DATA_FILEPATH,
                dataType: 'json',
                cache: false,
                success: function(data) {
                    var dataItems = that.model.create(data);
                    $.each(dataItems, function(i, obj) {
                        switch(obj.get('ev')){
                            case 'demo':
                                vm_demo.label.push(obj.get('app_name'));
                                vm_demo.x.push(obj.get('x'));
                                vm_demo.y.push(obj.get('y'));
                                vm_demo.y1.push(obj.get('total'));
                                vm_demo.detail.push(obj.get('detail'));
                                vm_demo.percent += obj.get('percent');
                                break;
                            case 'poc':
                                vm_poc.label.push(obj.get('customer_name'));
                                vm_poc.x.push(obj.get('x')+100);
                                vm_poc.y.push(obj.get('y'));
                                vm_poc.y1.push(obj.get('total'));
                                vm_poc.detail.push(obj.get('detail'));
                                vm_poc.percent += obj.get('percent');
                                break;
                            case 'live':
                                vm_live.label.push(obj.get('customer_name'));
                                vm_live.x.push(obj.get('x')+200);
                                vm_live.y.push(obj.get('y'));
                                vm_live.y1.push(obj.get('total'));
                                vm_live.detail.push(obj.get('detail'));
                                vm_live.percent += obj.get('percent');
                                break;
                            case 'ns':
                                vm_ns.label.push(obj.get('app_name'));
                                vm_ns.x.push(obj.get('x')+300);
                                vm_ns.y.push(obj.get('y'));
                                vm_ns.y1.push(obj.get('total'));
                                vm_ns.detail.push(obj.get('detail'));
                                vm_ns.percent += obj.get('percent');
                                break;
                        }
                        usedPrice += obj.get('percent');
                        if  (flg == 0){
                            totalValue = obj.get('total_value');
                            flg = 1;
                        }
                    });

                    var datalist=[{label: "DEMO" +'(' + that._forPercent(vm_demo.percent,4) + ')',data:{label:vm_demo.label,x:vm_demo.x,y:vm_demo.y, y1:vm_demo.y1,detail:vm_demo.detail}},
                        {label: "POC" +'(' + that._forPercent(vm_poc.percent,4)  + ')',data:{label:vm_poc.label,x:vm_poc.x,y:vm_poc.y, y1:vm_poc.y1,detail:vm_poc.detail}},
                        {label: "LIVE" +'(' + that._forPercent(vm_live.percent,4) + ')',data:{label:vm_live.label,x:vm_live.x,y:vm_live.y, y1:vm_live.y1,detail:vm_live.detail}},
			            {label: "NSSOL-SH" +'(' + that._forPercent(vm_ns.percent,4) + ')',data:{label:vm_ns.label,x:vm_ns.x,y:vm_ns.y, y1:vm_ns.y1,detail:vm_ns.detail}}];

                    var data = {totalvalue: totalValue, left: that._forPercent(1-usedPrice,4), datalist: datalist};

					df.resolve(data);
				},
                error:function(XmlHttpRequest,textStatus, errorThrown)
                {
                    alert(XmlHttpRequest.responseText);
                }
			});
            return df.promise();
		},

        _vmClass: function(){
            this.label = [];
            this.x = [];
            this.y = [];
            this.y1 = [];
            this.detail = [];
            this.percent = 0;
        },

        _forPercent: function(Dight,How){
            Dight = Math.round(Dight*Math.pow(10,How))/Math.pow(10,How)*100 + '%';
            return Dight;
    }
};

	// sample.chart.logic.BubbLogicでグローバルに公開する
	h5.core.expose(bubbLogic);
})();
