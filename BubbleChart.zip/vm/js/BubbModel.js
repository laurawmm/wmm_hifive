(function() {
	// =========================================================================
	// Constants
	// =========================================================================

	// =========================================================================
	// Cache
	// =========================================================================

	// =========================================================================
	// Functions
	// =========================================================================

	// =========================================================================
	// Body
	// =========================================================================

	// データモデルマネージャを作成する
	var bubbManager = h5.core.data.createManager('BubbManager');

	// データモデルを生成
	var bubbModel = bubbManager.createModel({
		name: 'BubbManager',
		schema: {
			// ID
			id: {
				id: true,
				type: 'integer'
			},

            // customer_name
            customer_name: {
                type: 'string',
                constraint: {
                    notNull: true
                }
            },

            // app_name
            app_name: {
                type: 'string',
                constraint: {
                    notNull: true
                }
            },

            // total
            total: {
                type: 'number',
                constraint: {
                    notNull: true
                }
            },

            // totalvalue
            total_value: {
                type: 'number',
                constraint: {
                    notNull: true
                }
            },

            // percent
            percent: {
                type: 'number',
                constraint: {
                    notNull: true
                }
            },

            // ev
            ev: {
                type: 'string',
                constraint: {
                    notNull: true
                }
            },

			// x軸
			x: {
				type: 'number',
                constraint: {
                    notNull: true
                }
			},

            // y軸
            y: {
                type: 'number',
                constraint: {
                    notNull: true
                }
            },

            // detail
            detail: {
                type: 'string',
                constraint: {
                    notNull: true
                }
            }
		}
	});

	// sample.chart.model.BubbModelでグローバルに公開する
	h5.u.obj.expose('sample.chart.model', {
		BubbModel: bubbModel
	});
})();
