$(function() {
	h5.core.controller('#content', sample.todo.controller.TodoController);
});